# Demo API
Client Demo API

# Folder Structure

## config
    - config.yaml

## Source Code
- `main.py` Main Routing
- `dlp.py` DLP functions

## CICD
- `Dockerfile` Dockerfile
- `requirements.txt` Dependencies used in Dockerfile


# Cloud Run DLP Service

This repository hosts a Cloud Run service written in Python that provides RESTful endpoints for de-identification, re-identification, and other data privacy tasks using Google Cloud’s Data Loss Prevention (DLP) API.

# Features

-  De-identification
Redacts or masks sensitive data in input payloads using DLP API.

-  Re-identification
Restores de-identified data to its original form with secure key management.

- Flexible API
Exposes multiple HTTP endpoints to perform different DLP operations.

- Containerized Deployment
Runs as a fully managed Cloud Run service with horizontal scalability and secure service account support.


# Repository Structure


| File               | Description                                                     |
| ------------------ | --------------------------------------------------------------- |
| `main.py`          | Flask app that defines the HTTP API endpoints.                  |
| `dlp.py`           | DLP client logic for de-identification, re-identification, etc. |
| `Dockerfile`       | Docker container definition for Cloud Run deployment.           |
| `requirements.txt` | Python dependencies for building the service.                   |

# API Endpoints

| Endpoint        | Path              | Description                                         | Method |
| --------------- | ----------------- | --------------------------------------------------- | ------ |
| Health Check    | `/`               | Returns a simple health status.                     | GET    |
| Server Info     | `/serverinfo`     | Returns server information and environment details. | GET    |
| DLP Inspect     | `/dlp-inspect`    | Scans input data for sensitive information.         | POST   |
| DLP De-identify | `/dlp-deidentify` | Redacts or masks sensitive data.                    | POST   |
| DLP Re-identify | `/dlp-reidentify` | Restores de-identified data to its original form.   | POST   |


# Deployment Instructions

- Build and Push Docker Image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/cloudrun-dlp-service

- Deploy to Cloud Run
gcloud run deploy cloudrun-dlp-service \
  --image gcr.io/YOUR_PROJECT_ID/cloudrun-dlp-service \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars PROJECT_ID=...,DLP_KEY_RING=...,DLP_KEY_NAME=...,KMS_KEY_NAME=...

# Environmental Varibles

| Variable       | Description                                  |
| -------------- | -------------------------------------------- |
| `PROJECT_ID`   | GCP project ID                               |
| `DLP_KEY_RING` | KMS key ring for DLP encryption              |
| `DLP_KEY_NAME` | KMS key name for DLP encryption              |
| `KMS_KEY_NAME` | Full resource name of the KMS key (optional) |

# IAM Permissions

Ensure the Cloud Run service account has:

roles/dlp.user — To call DLP API.
roles/cloudkms.cryptoKeyEncrypterDecrypter — For re-identification.


