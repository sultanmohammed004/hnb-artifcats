package com.HNB.CustomerRelationshipAccounts.controller;

import com.HNB.CustomerRelationshipAccounts.service.AccountDepositAchTransactionsService;
import com.HNB.CustomerRelationshipAccounts.model.AccountDepositAchTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/ach-deposits")
public class AccountDepositAchTransactionController {

    @Autowired
    private AccountDepositAchTransactionsService achDepositService;

    @GetMapping("/accounts/{accountId}")
    public List<AccountDepositAchTransactions> getAchDepositsByAccountId(@PathVariable String accountId) {
        return achDepositService.getAchDepositsByAccountId(accountId);
    }
}
