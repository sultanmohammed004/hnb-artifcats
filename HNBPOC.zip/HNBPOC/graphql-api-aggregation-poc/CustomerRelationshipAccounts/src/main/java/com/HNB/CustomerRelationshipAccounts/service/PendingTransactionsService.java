package com.HNB.CustomerRelationshipAccounts.service;

import com.HNB.CustomerRelationshipAccounts.model.PendingTransactions;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PendingTransactionsService {

    private List<PendingTransactions> pendingTransactionsList = new ArrayList<>();

    public PendingTransactionsService() {
        pendingTransactionsList.add(createPendingTransactions("1", "ACC1"));
        pendingTransactionsList.add(createPendingTransactions("1", "ACC1-1"));
        pendingTransactionsList.add(createPendingTransactions("2", "ACC1"));
        pendingTransactionsList.add(createPendingTransactions("2", "ACC2"));
        pendingTransactionsList.add(createPendingTransactions("3", "ACC3"));
        pendingTransactionsList.add(createPendingTransactions("4", "ACC4"));
    }

    private PendingTransactions createPendingTransactions(String customerId, String accountId) {
        PendingTransactions pt = new PendingTransactions();

        List<String> transactionTypes = List.of("Deposit", "Debit", "Credit");
        Random random = new Random();
        int randomIndex = random.nextInt(transactionTypes.size());
        pt.setTransactionAmountType(transactionTypes.get(randomIndex));

        pt.setCustomerId(customerId);
        pt.setAccountId(accountId);
        pt.setPendingTransactionId("PEN-TRAN-"+customerId+"-"+accountId);

        Calendar startDate = Calendar.getInstance();
        startDate.set(2024, Calendar.JANUARY, 1);
        long startMillis = startDate.getTimeInMillis();

        Calendar endDate = Calendar.getInstance();
        endDate.set(2025, Calendar.APRIL, 14);
        long endMillis = endDate.getTimeInMillis();

        long randomMillis = startMillis + (long) (Math.random() * (endMillis - startMillis));
        Date randomDate = new Date(randomMillis);
        pt.setPostingDate(String.format("%1$td%1$tm%1$tY", randomDate));

        return pt;
    }

    public List<PendingTransactions> getPendingTransactionsByCustomerId(String customerId) {
        List<PendingTransactions> result = new ArrayList<>();
        for (PendingTransactions pt : pendingTransactionsList) {
            if (pt.getCustomerId().equals(customerId)) {
                result.add(pt);
            }
        }
        return result;
    }

    public List<PendingTransactions> getPendingTransactionsByAccountId(String accountId) {
        List<PendingTransactions> result = new ArrayList<>();
        for (PendingTransactions pt : pendingTransactionsList) {
            if (pt.getAccountId().equals(accountId)) {
                result.add(pt);
            }
        }
        return result;
    }
}
