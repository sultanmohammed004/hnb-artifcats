package com.HNB.CustomerRelationshipAccounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerRelationshipAccountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRelationshipAccountsApplication.class, args);
	}

}
