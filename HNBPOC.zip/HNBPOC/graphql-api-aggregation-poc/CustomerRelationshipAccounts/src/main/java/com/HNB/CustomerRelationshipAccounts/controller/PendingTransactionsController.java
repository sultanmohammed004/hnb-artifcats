package com.HNB.CustomerRelationshipAccounts.controller;

import com.HNB.CustomerRelationshipAccounts.model.PendingTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.HNB.CustomerRelationshipAccounts.service.PendingTransactionsService;

import java.util.List;

@RestController
@RequestMapping("/pending-transactions")
public class PendingTransactionsController {

    @Autowired
    private PendingTransactionsService pendingTransactionService;

    @GetMapping("/customer/{customerId}")
    public List<PendingTransactions> getAllPendingTransactions(@PathVariable String customerId) {
        return pendingTransactionService.getPendingTransactionsByCustomerId(customerId);
    }

    @GetMapping("/account/{accountId}")
    public List<PendingTransactions> getAllPendingTransactionsByAccountId(@PathVariable String accountId) {
        return pendingTransactionService.getPendingTransactionsByAccountId(accountId);
    }
}
