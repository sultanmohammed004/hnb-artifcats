package com.HNB.CustomerRelationshipAccounts.controller;

import com.HNB.CustomerRelationshipAccounts.model.*;
import com.HNB.CustomerRelationshipAccounts.service.AggregatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

@Controller
public class GraphQLResolver {

    @Autowired
    private AggregatorService aggregatorService;

    @QueryMapping
    public CustomerAccountInfo getCustomerAccountInfo(@Argument String customerId) {

        var customerRelationshipAccount = aggregatorService.getCustomerDetailsById(customerId);
        var pendingTransactions = aggregatorService.getPendingTransactionDetailsByCustomerId(customerId);
        String accountId = aggregatorService.getAccountIdByCustomerId(customerId);
        var accountDepositsAchTransactions = aggregatorService.getAccountDepositAchTransactionsByAccountId(accountId);

        CustomerAccountInfo customerInfo = new CustomerAccountInfo();
        customerInfo.setCustomerRelationshipAccount(customerRelationshipAccount);
        customerInfo.setPendingTransactions(pendingTransactions);
        customerInfo.setAccountDepositAchTransactions(accountDepositsAchTransactions);

        return customerInfo;
    }

    @QueryMapping
    public TransactionHistory getTransactionHistory(@Argument String accountId) {

        var pendingTransactionsByAccountId = aggregatorService.getPendingTransactionsByAccountId(accountId);
        var accountDepositsAchTransactions = aggregatorService.getAccountDepositAchTransactionsByAccountId(accountId);

        TransactionHistory transactionHistory = new TransactionHistory();
        transactionHistory.setPendingTransactions(pendingTransactionsByAccountId);
        transactionHistory.setAccountDepositAchTransactions(accountDepositsAchTransactions);

        return transactionHistory;
    }


}
