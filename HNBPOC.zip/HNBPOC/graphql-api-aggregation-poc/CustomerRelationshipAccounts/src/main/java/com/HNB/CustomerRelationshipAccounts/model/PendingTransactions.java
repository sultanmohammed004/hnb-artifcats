package com.HNB.CustomerRelationshipAccounts.model;

import lombok.Data;

@Data
public class PendingTransactions {

    private String pendingTransactionId;
    private String accountId;
    private String transactionAmountType;
    private String postingDate;
    private String customerId;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPendingTransactionId() {
        return pendingTransactionId;
    }

    public void setPendingTransactionId(String pendingTransactionId) {
        this.pendingTransactionId = pendingTransactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getTransactionAmountType() {
        return transactionAmountType;
    }

    public void setTransactionAmountType(String transactionAmountType) {
        this.transactionAmountType = transactionAmountType;
    }

    public String getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(String postingDate) {
        this.postingDate = postingDate;
    }



}
