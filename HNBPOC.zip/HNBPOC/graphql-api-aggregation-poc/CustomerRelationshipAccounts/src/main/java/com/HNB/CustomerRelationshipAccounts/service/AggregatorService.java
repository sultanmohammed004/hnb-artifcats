package com.HNB.CustomerRelationshipAccounts.service;

import com.HNB.CustomerRelationshipAccounts.model.AccountDepositAchTransactions;
import com.HNB.CustomerRelationshipAccounts.model.CustomerRelationshipAccount;
import com.HNB.CustomerRelationshipAccounts.model.PendingTransactions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class AggregatorService {

    @Autowired
    private RestTemplate restTemplate;

    public CustomerRelationshipAccount getCustomerDetailsById(String customerId) {

        return restTemplate.getForObject("http://localhost:8081/customer-relationship-accounts/getCustomer/{customerId}", CustomerRelationshipAccount.class, customerId);

    }

    public List<PendingTransactions> getPendingTransactionDetailsByCustomerId(String customerId){

        return restTemplate.exchange(
                "http://localhost:8081/pending-transactions/customer/" + customerId,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<PendingTransactions>>() {
                }).getBody();

    }

    public List<AccountDepositAchTransactions> getAccountDepositAchTransactionsByAccountId(String accountId){

        return restTemplate.exchange(
                "http://localhost:8081/ach-deposits/accounts/" + accountId,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<AccountDepositAchTransactions>>() {
                }).getBody();

    }

    public String getAccountIdByCustomerId(String customerId){

        CustomerRelationshipAccount custAccount =  restTemplate.getForObject("http://localhost:8081/customer-relationship-accounts/getCustomer/{customerId}", CustomerRelationshipAccount.class, customerId);
        return custAccount.getAccountId();

    }

    public List<PendingTransactions> getPendingTransactionsByAccountId(String accountId){

        return restTemplate.exchange(
                "http://localhost:8081/pending-transactions/account/" + accountId,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<PendingTransactions>>() {
                }).getBody();

    }
}
