package com.HNB.CustomerRelationshipAccounts.service;


import com.HNB.CustomerRelationshipAccounts.model.AccountDepositAchTransactions;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Random;

@Service
public class AccountDepositAchTransactionsService {

    private List<AccountDepositAchTransactions> depositTransactions = new ArrayList<>();

    public AccountDepositAchTransactionsService(){

        depositTransactions.add(createDepositTransactions("ACC1", "PEN-TRAN-1-ACC1"));
        depositTransactions.add(createDepositTransactions("ACC1", "PEN-TRAN-2-ACC1"));
        depositTransactions.add(createDepositTransactions("ACC1-1", "PEN-TRAN-1-ACC1-1"));
        depositTransactions.add(createDepositTransactions("ACC2", "PEN-TRAN-2-ACC2"));

    }

    private AccountDepositAchTransactions createDepositTransactions(String accountId, String pendingTransactionId) {
        AccountDepositAchTransactions depositTransaction = new AccountDepositAchTransactions();

        depositTransaction.setAccountId(accountId);
        depositTransaction.setPendingTransactionId(pendingTransactionId);

        String uuid = UUID.randomUUID().toString().replace("-", "");
        String formattedUuid = uuid.substring(0, 6) + "-" +
                uuid.substring(6, 10) + "-" +
                uuid.substring(10, 14) + "-" +
                uuid.substring(14, 18) + "-" +
                uuid.substring(18, 28);
        depositTransaction.setAccountDepositAchTransactionId(formattedUuid);

        depositTransaction.setAccountDepositsAchBatchId("Batch-"+formattedUuid);
        depositTransaction.setAccountDepositsAchFileId("File-"+formattedUuid);

        long random15DigitNumber = (long) (Math.random() * 1000000000000000L);
        depositTransaction.setBankNumber(String.valueOf(random15DigitNumber));

        return depositTransaction;
    }

    public List<AccountDepositAchTransactions> getAchDepositsByAccountId(String accountId) {
        List<AccountDepositAchTransactions> filteredTransactions = new ArrayList<>();
        for (AccountDepositAchTransactions transaction : depositTransactions) {
            if (transaction.getAccountId().equals(accountId)) {
                filteredTransactions.add(transaction);
            }
        }
        return filteredTransactions;
    }
}
