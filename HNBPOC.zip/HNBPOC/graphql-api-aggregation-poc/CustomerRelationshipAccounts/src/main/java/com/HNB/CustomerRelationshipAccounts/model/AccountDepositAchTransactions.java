package com.HNB.CustomerRelationshipAccounts.model;

import lombok.Data;

@Data
public class AccountDepositAchTransactions {

    private String accountDepositAchTransactionId;
    private String pendingTransactionId;
    private String accountId;
    private String bankNumber;
    private String accountDepositsAchFileId;
    private String accountDepositsAchBatchId;

    public String getPendingTransactionId() {
        return pendingTransactionId;
    }

    public void setPendingTransactionId(String pendingTransactionId) {
        this.pendingTransactionId = pendingTransactionId;
    }

    public String getAccountDepositAchTransactionId() {
        return accountDepositAchTransactionId;
    }

    public void setAccountDepositAchTransactionId(String accountDepositAchTransactionId) {
        this.accountDepositAchTransactionId = accountDepositAchTransactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public String getAccountDepositsAchFileId() {
        return accountDepositsAchFileId;
    }

    public void setAccountDepositsAchFileId(String accountDepositsAchFileId) {
        this.accountDepositsAchFileId = accountDepositsAchFileId;
    }

    public String getAccountDepositsAchBatchId() {
        return accountDepositsAchBatchId;
    }

    public void setAccountDepositsAchBatchId(String accountDepositsAchBatchId) {
        this.accountDepositsAchBatchId = accountDepositsAchBatchId;
    }


}
