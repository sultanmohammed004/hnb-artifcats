package com.HNB.CustomerRelationshipAccounts.service;

import org.springframework.stereotype.Service;

import com.HNB.CustomerRelationshipAccounts.model.CustomerRelationshipAccount;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CustomerService {

    private List<CustomerRelationshipAccount> customers = new ArrayList<>();

    public CustomerService() {
        customers.add(createCustomer("1", "John Doe"));
        customers.add(createCustomer("2", "Jane Smith"));
        customers.add(createCustomer("3", "Alice Johnson"));
        customers.add(createCustomer("4", "Bob Brown"));
    }

    public CustomerRelationshipAccount getCustomerById(String customerId) {
        return customers.stream()
                .filter(customer -> customer.getCustomerId().equals(customerId))
                .findFirst()
                .orElse(null);
    }

    private CustomerRelationshipAccount createCustomer(String id, String name) {
        CustomerRelationshipAccount customer = new CustomerRelationshipAccount();
        customer.setCustomerRelationshipsAccountId(id);
        customer.setCustomerId(id);
        customer.setNickname(name);
        customer.setRelationshipTypeCode("TypeCode");
        customer.setRelationshipTypeDescription("TypeDescription");
        customer.setRelationshipStatus("Active");
        customer.setAccountOwnershipIndicator(true);
        customer.setOwnerDesignation("Owner");
        customer.setOwnerDesignationTitle("Title");
        customer.setOriginatingBankNumber("BankNumber");
        customer.setSignerPresentAtAccountOpeningIndicator(true);
        customer.setEffectiveStartDate(new Date());
        customer.setEffectiveEndDate(null);
        customer.setAccountId("ACC"+id);
        customer.setExternalAccountId("ExternalAccountId "+id);
        customer.setAccountShortNickname("ShortNickname "+id);
        customer.setCustomerRelationshipsCustomerId("CustomerRelationshipsCustomerId "+id);
        return customer;
    }
}