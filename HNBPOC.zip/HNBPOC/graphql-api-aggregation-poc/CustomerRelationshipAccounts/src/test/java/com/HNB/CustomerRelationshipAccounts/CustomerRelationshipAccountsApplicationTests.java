package com.HNB.CustomerRelationshipAccounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRelationshipAccountsApplicationTests {

	@Test
	void contextLoads() {
	}

}
