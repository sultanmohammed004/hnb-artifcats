# Standard libraries for data handling and logging
import datetime
import gzip
import io
import logging
import uuid

# Apache Beam components for data processing pipeline
import apache_beam as beam
from apache_beam import combiners
from apache_beam.io.gcp.bigquery import WriteToBigQuery
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions, SetupOptions

# Cryptography libraries for decryption
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# Google Cloud clients for secret management and storage
from google.cloud import secretmanager_v1
from google.cloud import storage


# Download, Decrypt and Decompress DoFn
class DownloadFileAndDecryptFn(beam.DoFn):
    """A Beam DoFn to download, decrypt, and decompress a file from GCS.
    Downloads an encrypted and gzipped file from GCS, retrieves the decryption key from Secret Manager,
    decrypts using AES-GCM, decompresses the file, and uploads the plaintext to a target GCS location.
    """
    def __init__(self, source_path, secret_id, project_id, output_location):
        self.source_path = source_path
        self.secret_id = secret_id
        self.project_id = project_id
        self.output_location = output_location
        self.token = None


    def setup(self):
        self.storage_client = storage.Client()
        client = secretmanager_v1.SecretManagerServiceClient()

        def sample_access_secret_version(param=None):
            request = secretmanager_v1.AccessSecretVersionRequest(
                name=f"projects/{self.project_id}/secrets/{self.secret_id.get()}/versions/latest",
            )
            response = client.access_secret_version(request=request)
            return response.payload.data.decode('UTF-8')
        self.token = sample_access_secret_version()

    def process(self, element):
        """
            Downloads the encrypted file, decrypts and decompresses it, yields lines, and uploads the result.
            """
        try:
            # Constants for decryption
            IV_LENGTH = 12
            SALT_LENGTH = 16
            KEY_SIZE = 32
            ITERATIONS = 65536

            # Get GCS source and output paths
            gcs_path = self.source_path.get()
            password = self.token
            output_path = self.output_location.get()

            # Parse GCS bucket and blob names for input and output
            parts = gcs_path.replace("gs://", "").split("/", 1)
            bucket_name = parts[0]
            blob_name = parts[1]

            #Upload the decrypted file location
            output_parts = output_path.replace("gs://", "").split("/", 1)
            output_bucket_name = output_parts[0]
            output_blob_name = output_parts[1]

            bucket_output = self.storage_client.bucket(output_bucket_name)
            output_blob = bucket_output.blob(output_blob_name)

            # Download encrypted file from GCS
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            encrypted_bytes = blob.download_as_bytes()

            # Extract IV, salt, and ciphertext from the encrypted file
            iv = encrypted_bytes[:IV_LENGTH]
            salt = encrypted_bytes[IV_LENGTH:IV_LENGTH + SALT_LENGTH]
            ciphertext = encrypted_bytes[IV_LENGTH + SALT_LENGTH:]

            # Derive key using PBKDF2
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=KEY_SIZE,
                salt=salt,
                iterations=ITERATIONS,
                backend=default_backend()
            )
            key = kdf.derive(password.encode())
            aesgcm = AESGCM(key)

            # Decrypt ciphertext using AES-GCM
            decrypted_gz_content = aesgcm.decrypt(iv, ciphertext, None)

            # Decompress the decrypted gzip content and yield lines
            with gzip.GzipFile(fileobj=io.BytesIO(decrypted_gz_content), mode='rb') as gz_in:
                decompressed_data = gz_in.read().decode('utf-8')
                output_string = ""
                for line in decompressed_data.splitlines():
                    output_string += line
                    output_string += "\n"
                    yield line
                # Upload the decompressed data to the output GCS location
                output_blob.upload_from_string(output_string, content_type='text/csv')
        except Exception as e:
            logging.error(f"Error in DownloadFileAndDecryptFn: {e}")
            raise


class CreateAudit(beam.DoFn):
    """A Beam DoFn to create an audit entry for the processed file.
    Generates a dictionary with UUID, file paths, timestamp, and record count.
    """
    def __init__(self, source_path, output_location ):
        # Initialize with source and output locations
        self.source_path = source_path
        self.output_location = output_location

    def process(self, element):
        """
            Builds and yields an audit information dictionary.
            """
        file_info = {
            "uuid": str(uuid.uuid4()),
            "source_file_path": self.source_path.get(),
            "target_file_path": self.output_location.get(),
            "insert_timestamp": str(datetime.datetime.now()),
            "record_count": int(element) - 1
        }
        yield file_info


# Custom pipeline options
class MyOptions(PipelineOptions):
    """Custom pipeline options for the Dataflow job.
    Defines arguments for project, audit table, source file, secret, and output location.
    """
    @classmethod
    # Main pipeline function
    def _add_argparse_args(cls, parser):
        parser.add_argument('--projectId', help='GCP Project ID number')
        parser.add_argument("--auditTableId", help="BigQuery Audit Table Id")
        parser.add_value_provider_argument('--sourceFilePath', help='GCS source file path')
        parser.add_value_provider_argument('--secretId', help='Secret ID for GCP Secret Manager')
        parser.add_value_provider_argument('--outputLocation', help='Output location for decrypted data')

# Main pipeline function
def run(argv=None, save_main_session=True):
    """
        Main function to define and run the Beam pipeline.
        Sets up pipeline options, runs the download/decrypt process, counts records,
        creates an audit entry, and writes the audit to BigQuery.
        """
    # Set up pipeline options and custom options
    pipeline_options = PipelineOptions()
    dataflow_options = pipeline_options.view_as(MyOptions)

    pipeline_options.view_as(StandardOptions).runner = 'DataflowRunner'
    pipeline_options.view_as(StandardOptions).streaming = False
    pipeline_options.view_as(SetupOptions).save_main_session = save_main_session

    pipeline_obj = beam.Pipeline(options=pipeline_options)

    # Pipeline steps: download, decrypt, decompress, and count records
    decrypted_lines = (
        pipeline_obj
        | "Start Dummy" >> beam.Create([1])
        | "Download and Decrypt" >> beam.ParDo(DownloadFileAndDecryptFn(source_path=dataflow_options.sourceFilePath,
                                                                        secret_id=dataflow_options.secretId,
                                                                        project_id=dataflow_options.projectId,
                                                                        output_location=dataflow_options.outputLocation)))

    element_count = decrypted_lines| "Count Elements" >> combiners.Count.Globally()
    # Create audit entry with record count and metadata
    audit_entry = (element_count| "Create Audit" >>
     beam.ParDo(CreateAudit(source_path=dataflow_options.sourceFilePath,
                 output_location=dataflow_options.outputLocation)))

    # Write audit entry to BigQuery
    (audit_entry | "Write Audit Entry to BigQuery" >> WriteToBigQuery(table=dataflow_options.auditTableId,
                     write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                     create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER))

    pipeline_obj.run()

# Entry point
if __name__ == "__main__":
    run()