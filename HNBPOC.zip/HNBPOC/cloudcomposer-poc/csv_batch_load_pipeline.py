# Standard libraries for data handling and logging
import datetime
import json
import logging
import re
import uuid
import io
import gzip

# Apache Beam components for data processing pipeline
import apache_beam as beam
from apache_beam.io import ReadFromText
from apache_beam.io.gcp.bigquery import WriteToBigQuery
from apache_beam.io.gcp.bigtableio import WriteToBigTable
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions, SetupOptions
from apache_beam.options.value_provider import ValueProvider

# Google Cloud BigTable components
from google.cloud import bigtable
from google.cloud.bigtable import row
from google.cloud.bigtable.row import DirectRow


# Creates an audit record with message details, timestamp, and metadata
@staticmethod
def get_audit_record(message, metadata, row_key):
    """
    Creates a structured audit record for tracking and error handling
    Args:
        message: The original message content
        metadata: Additional information about the message processing
        row_key: Unique identifier for the record
    Returns:
        Dictionary with audit information
    """
    return {
        'message_body': str(message),
        'insert_timestamp': datetime.datetime.now().isoformat(),
        'metadata': metadata,
        'row_key': row_key
    }


# Static method to parse CSV into JSON structure
@staticmethod
def parse_json(values: list) -> dict:
    event = {
        "verb": (values[3]).strip(),
        "eventType": (values[4]).strip(),
        "applicationId": (values[5]).strip(),
        "applicationName": (values[6]).strip(),
        "sourceType": (values[7]).strip(),
        "publicationId": (values[8]).strip()
    }

    metadata = {
        "correlationId": (values[0]).strip(),
        "sessionId": (values[1]).strip(),
        "classificationHighwatermark": (values[2]).strip(),
        "event": event
    }

    to_account = {
        "accountId": (values[13]).strip(),
        "invalidAccountNumber": (values[14]).strip(),
        "virtualAccountNumber": (values[15]).strip(),
        "externalAccountNumber": (values[16]).strip(),
        "routingNumber": (values[17]).strip(),
        "transactionAmountType": (values[18]).strip(),
        "transactionEngineReference": (values[19]).strip(),
        "referenceBaiCodeId": (values[20]).strip()
    }

    from_account = {
        "accountId": (values[21]).strip(),
        "invalidAccountNumber": (values[22]).strip(),
        "virtualAccountNumber": (values[23]).strip(),
        "externalAccountNumber": (values[24]).strip(),
        "routingNumber": (values[25]).strip(),
        "transactionAmountType": (values[26]).strip(),
        "transactionEngineReference": (values[27]).strip(),
        "referenceBaiCodeId": (values[28]).strip()
    }

    originator = {
        "originatorReference": (values[37]).strip(),
        "originatorName": (values[39]).strip()
    }

    distribution = {
        "distributionApplicationPoint": (values[40]).strip(),
        "distributionApplicationReference": (values[41]).strip(),
    }

    receiver = {
        "receiverReference": (values[42]).strip(),
        "receiverName": (values[43]).strip()
    }

    return_obj = {
        "returnReference": (values[44]).strip(),
        "returnReasonCode": (values[45]).strip(),
        "returnReasonDescription": (values[46]).strip()
    }

    noticeOfChange = {
        "noticeOfChangeReference": (values[47]).strip(),
        "noticeOfChangeCode": (values[48]).strip(),
        "noticeOfChangeDescription": (values[49]).strip()
    }

    account_achtransactions = {
        "accountAchtransactionId": (values[9]).strip(),
        "transactionAmount": (values[10]).strip(),
        "currencyCode": (values[11]).strip(),
        "transactionTimestamp": (values[12]).strip(),
        "toAccount": to_account,
        "fromAccount": from_account,
        "accountAchFileId": (values[29]).strip(),
        "accountAchBatchId": (values[30]).strip(),
        "shortReference": (values[31]).strip(),
        "shortDescription": (values[32]).strip(),
        "traceNumber": (values[33]).strip(),
        "descriptiveDate": (values[34]).strip(),
        "effectiveDate": (values[35]).strip(),
        "settlementDate": (values[36]).strip(),
        "referenceSecCodeId": (values[37]).strip(),
        "originator": originator,
        "distribution": distribution,
        "receiver": receiver,
        "return": return_obj,
        "noticeOfChange": noticeOfChange,
        "addendaText": (values[50]).strip()
    }

    payload = {
        "account-achtransactions": account_achtransactions
    }

    json_structure = {
        "_metadata": metadata,
        "payload": payload
    }

    return json_structure

# Beam DoFn classes
class ParseData(beam.DoFn):

    # Output tags for valid and invalid messages
    OUTPUT_TAG_VALID_MESSAGES = 'tag_valid_messages'
    OUTPUT_TAG_INVALID_MESSAGES = 'tag_invalid_messages'

    def process(self, element):
        values = re.split(",", element)
        if len(values) == 52 or len(values) == 51:
            process_data = parse_json(values)
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_VALID_MESSAGES, process_data)

        else:

            audit_record = {
                'message_body': str(element),
                'insert_timestamp': datetime.datetime.now().isoformat(),
                'metadata': "Validation errors: Input data contains less than 51 or 52 columns",
                'row_key': "None"
            }
            # Log error and create audit record for invalid message
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_INVALID_MESSAGES, audit_record)


class CreateRow(beam.DoFn):
    # Output tags for valid and invalid messages
    OUTPUT_TAG_VALID_MESSAGES = 'tag_valid_messages'
    OUTPUT_TAG_INVALID_MESSAGES = 'tag_invalid_messages'

    def process(self, element):
        today = datetime.date.today()
        uuid_key = str(uuid.uuid4())
        row_key = str(today) + "#" + uuid_key
        try:
            bigtable_timestamp = datetime.datetime.now()
            row_key_identifier = f"{row_key}".encode('utf-8')
            bt_row_obj = row.DirectRow(row_key_identifier)
            column_family_id = "raw_message"

            decoded_element = element.decode('utf-8')

            if isinstance(decoded_element, str):
                bt_row_obj.set_cell(column_family_id, "raw_data", decoded_element.encode('utf-8'),
                                    timestamp=bigtable_timestamp)

            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_VALID_MESSAGES, bt_row_obj)
        except Exception as e:
            logging.error(f"Error processing element: {e}")
            audit_record = {
                'message_body': str(element),
                'insert_timestamp': datetime.datetime.now().isoformat(),
                'metadata': f"Validation errors: {e}",
                'row_key': f"{row_key}"
            }
            # Log error and create audit record for invalid message
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_INVALID_MESSAGES, audit_record)



class ProcessingAndTransformDoFn(beam.DoFn):
    # Output tags for valid and invalid messages
    OUTPUT_TAG_VALID_MESSAGES = 'tag_valid_messages'
    OUTPUT_TAG_INVALID_MESSAGES = 'tag_invalid_messages'

    def process(self, element):
        try:
            message = element
            correlation_id = message.get('_metadata', {}).get('correlationId', 'UNKNOWN')
            account_id = message.get('payload', {}).get('account-achtransactions', {}).get('toAccount', {}).get('accountId', 'UNKNOWN')
            account_achtransaction_id = message.get('payload', {}).get('account-achtransactions', {}).get('accountAchtransactionId', 'UNKNOWN')

            row_key_identifier = f"{correlation_id}#{account_id}#{account_achtransaction_id}".encode('utf-8')
            bigtable_timestamp = datetime.datetime.now()

            bt_row_obj = row.DirectRow(row_key_identifier)
            for key, value in message.items():
                if value is not None:
                    column_family_id = "aggregated_transaction"
                    if isinstance(value, str):
                        bt_row_obj.set_cell(column_family_id, key, value.encode('utf-8'), timestamp=bigtable_timestamp)
                    elif isinstance(value, (int, float)):
                        bt_row_obj.set_cell(column_family_id, key, (str(value)).encode('utf-8'), timestamp=bigtable_timestamp)
                    elif isinstance(value, (dict, list)):
                        bt_row_obj.set_cell(column_family_id, key, (json.dumps(value)).encode('utf-8'), timestamp=bigtable_timestamp)
                    elif isinstance(value, bool):
                        bt_row_obj.set_cell(column_family_id, key, (str(value)).encode('utf-8'), timestamp=bigtable_timestamp)
                    elif isinstance(value, datetime.datetime):
                        bt_row_obj.set_cell(column_family_id, key, (value.isoformat()).encode('utf-8'), timestamp=bigtable_timestamp)
                    else:
                        bt_row_obj.set_cell(column_family_id, key, (str(value)).encode('utf-8'), timestamp=bigtable_timestamp)

            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_VALID_MESSAGES, bt_row_obj)

        except Exception as e:
            logging.error(f"Error processing element: {e}")
            audit_record = {
                'message_body': str(element),
                'insert_timestamp': datetime.datetime.now().isoformat(),
                'metadata': f"Validation errors: {e}",
                'row_key': f"{element.get('accountDepositsAchTransactionId', 'UNKNOWN') + "#" + {element.get('accountId', 'UNKNOWN')} }"
            }
            # Log error and create audit record for invalid message
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_INVALID_MESSAGES, audit_record)

# Custom pipeline options
class MyOptions(PipelineOptions):
    @classmethod
    def _add_argparse_args(cls, parser):
        parser.add_argument('--projectId', help='GCP Project ID')
        parser.add_argument('--instanceId', help='BigTable Instance ID')
        parser.add_argument('--batchDataTableId', help='BigTable Table ID')
        parser.add_argument("--auditTableId", help="BigQuery Audit Table Id")
        parser.add_value_provider_argument('--sourceFilePath', help='GCS source file path')
        parser.add_value_provider_argument('--decryptionPassword', help='Password to decrypt the file')

# Main pipeline function
def run(argv=None, save_main_session=True):
    pipeline_options = PipelineOptions()
    dataflow_options = pipeline_options.view_as(MyOptions)

    pipeline_options.view_as(StandardOptions).runner = 'DataflowRunner'
    pipeline_options.view_as(StandardOptions).streaming = False
    pipeline_options.view_as(SetupOptions).save_main_session = save_main_session

    pipeline_obj = beam.Pipeline(options=pipeline_options)

    # Read data from GCS bucket
    gcs_file_path = dataflow_options.sourceFilePath  # Path to the file in GCS
    lines = pipeline_obj | "Read Data from GCS" >> ReadFromText(gcs_file_path)


    formatted_data = (lines | "Format CSV Data" >> beam.ParDo(ParseData()).with_outputs(
                ParseData.OUTPUT_TAG_INVALID_MESSAGES, ParseData.OUTPUT_TAG_VALID_MESSAGES))

    raw_bt_records = (lines
                      | "Create BigTable Row" >> beam.ParDo(CreateRow()).with_outputs(
                CreateRow.OUTPUT_TAG_INVALID_MESSAGES, CreateRow.OUTPUT_TAG_VALID_MESSAGES))

    (raw_bt_records[CreateRow.OUTPUT_TAG_VALID_MESSAGES] |
    "Write Raw records to BigTable" >> WriteToBigTable(
        project_id=dataflow_options.projectId,
        instance_id=dataflow_options.instanceId,
        table_id=dataflow_options.batchDataTableId,
    ))

    processed_data = (formatted_data[ParseData.OUTPUT_TAG_VALID_MESSAGES]
     | "Implement Business Logic" >> beam.ParDo(ProcessingAndTransformDoFn()).with_outputs(
                ProcessingAndTransformDoFn.OUTPUT_TAG_INVALID_MESSAGES, ProcessingAndTransformDoFn.OUTPUT_TAG_VALID_MESSAGES))

    (processed_data[ProcessingAndTransformDoFn.OUTPUT_TAG_VALID_MESSAGES]
     | "Writing transformed records to BigTable" >> WriteToBigTable(
        project_id=dataflow_options.projectId,
        instance_id=dataflow_options.instanceId,
        table_id=dataflow_options.batchDataTableId
    ))

    (formatted_data[ParseData.OUTPUT_TAG_INVALID_MESSAGES]
      | "Write validation failed error to BigQuery" >> WriteToBigQuery(project=dataflow_options.projectId,
                                                               table=dataflow_options.auditTableId,
                                                               write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                                                               create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER))

    (raw_bt_records[CreateRow.OUTPUT_TAG_INVALID_MESSAGES]
     | "Write raw records conversion failed error to BigQuery" >> WriteToBigQuery(project=dataflow_options.projectId,
                                                                      table=dataflow_options.auditTableId,
                                                                      write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                                                                      create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER))

    (processed_data[ProcessingAndTransformDoFn.OUTPUT_TAG_INVALID_MESSAGES]
     | "Write Processed records conversion failed error to BigQuery" >> WriteToBigQuery(project=dataflow_options.projectId,
                                                                                  table=dataflow_options.auditTableId,
                                                                                  write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                                                                                  create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER))


    pipeline_obj.run()

# Entry point
if __name__ == "__main__":
    run()
