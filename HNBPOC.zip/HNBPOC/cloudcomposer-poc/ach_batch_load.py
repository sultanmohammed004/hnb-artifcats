# Import standard package
import datetime

# Import all the required Airflow pakckages
from airflow import DAG
from airflow.providers.standard.operators.python import PythonOperator, BranchPythonOperator
from airflow.providers.google.cloud.sensors.gcs import GCSObjectExistenceSensor
from airflow.providers.google.cloud.hooks.gcs import GCSHook
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator


# Define default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0
}


def validate_file_info(**kwargs):
    """Validates if the file has not already been processed or is a zero byte file"""
    ti = kwargs['ti']
    gcs_hook = GCSHook()
    file_name = 'ach.csv'
    # Get the size and md5 hash of the file
    size = gcs_hook.get_size(bucket_name='hnb-poc-demo', object_name=file_name)
    md5hash = gcs_hook.get_md5hash(bucket_name='hnb-poc-demo', object_name=file_name)
    file_info = {'file_size': size,"md5hash": md5hash, "file_path":"gs://hnb-poc-demo/ach.csv", "file_name": file_name}

    # Search the BQ Audit table for the file if it's already processed
    bq_hook = BigQueryHook(location='us-east4')
    query = 'SELECT uuid from [us-gcp-ame-con-ff12d-npd-1:olap_dataset.file_ingestion_audit] where md5_hash = "{}"'.format(
        file_info["md5hash"])
    results = bq_hook.get_records(query)
    if results:
        print("File already processed.")
        file_info["comments"] = "File already processed. Previous UUID is {}".format(results[0][0])
        file_info["task"] = "already_processed_audit"

    else:
        print("No existing record. Proceeding to zero byte check")
        if file_info["file_size"] != 0:
            print("Valid file. Proceed to insert new record.")
            file_info["comments"] = 'Added a new valid file ach.csv'
            file_info["task"] = "insert_valid_audit_record"
        else:
            file_info["comments"] = "Zero byte file received."
            file_info["task"] = "zero_byte_insert_audit"
    ti.xcom_push(key='file_info', value=file_info)
    return True
        

# Define a DAG with required configuration
dag = DAG(dag_id="ach_batch_load", start_date=datetime.datetime.now(), schedule_interval=None, catchup=False, render_template_as_native_obj=True)

# Sensor looking for the required CSV file
gcs_file_check = GCSObjectExistenceSensor(
            task_id='check_file_existence',
            bucket='hnb-poc-demo',
            object='ach.csv', 
            use_glob= False,
            impersonation_chain= None,
            dag=dag,
            )

# Validate the file 
validate_file_info = PythonOperator(
    task_id="validate_file_info",
    python_callable=validate_file_info,
    dag=dag,
    trigger_rule="all_success"
)

# Implement the further flow based on the validation result
def branch(**kwargs):
    ti = kwargs["ti"]
    file_info = ti.xcom_pull(task_ids = "validate_file_info", key='file_info')
    return [file_info["task"]]

branch_task = BranchPythonOperator( task_id='select_audit_process',
    python_callable=branch,
    dag=dag)

# Add an audit record for file being not valid as it's 0 bytes. 
audit_zero_byte_file = BigQueryInsertJobOperator(
        task_id="zero_byte_insert_audit",
        configuration={
            "query": {
                "query":"""
                INSERT INTO `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` 
                (uuid, file_name, file_size, file_path, md5_hash, insert_timestamp, comments) VALUES 
                (GENERATE_UUID(), 
                '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('file_name')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_size')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_path')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('md5hash')}}', 
                CURRENT_TIMESTAMP,
                "{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('comments')}}")
                """,
                "useLegacySql": False,
                "priority": "BATCH",
            }
        }, dag = dag
    )

# Add an audit record as the file is already processed
audit_processed_file = BigQueryInsertJobOperator(
        task_id="already_processed_audit",
        configuration={
            "query": {
                "query": """
                INSERT INTO `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` 
                (uuid, file_name, file_size, file_path, md5_hash, insert_timestamp, comments) VALUES 
                (GENERATE_UUID(), 
                '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('file_name')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_size')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_path')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('md5hash')}}', 
                CURRENT_TIMESTAMP,
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('comments')}}')
                """,
                "useLegacySql": False,
                "priority": "BATCH",
            }
        }, dag = dag
    )

# Add an audit record for the file being a valid one
create_file_audit_decrypt =BigQueryInsertJobOperator(
        task_id="insert_valid_audit_record",
        configuration={
            "query": {
                "query": """
                INSERT INTO `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` 
                (uuid, file_name, file_size, file_path, md5_hash, insert_timestamp, comments) VALUES 
                (GENERATE_UUID(), 
                '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('file_name')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_size')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('file_path')}}', 
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('md5hash')}}', 
                CURRENT_TIMESTAMP,
                '{{task_instance.xcom_pull(task_ids='validate_file_info',key='file_info').get('comments')}}')
                """,
                "useLegacySql": False,
                "priority": "BATCH",
            }
        }, dag = dag
    )

# Trigger a dataflow job to decrypt the encrypted ACH file
decrypt_dataflow = DataflowTemplatedJobStartOperator(
        task_id='decrypt_dataflow',
        job_name='decrypt-batch-test-container',
        project_id='us-gcp-ame-con-ff12d-npd-1',
        template='gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/optimal/templates/decrypt_extract_upload',
        # Replace with your GCP project ID
        location='us-east4',  # Replace with your Dataflow job location
        gcp_conn_id='google_cloud_default',  # Replace with your GCP connection ID
        parameters={
            'projectId': 'us-gcp-ame-con-ff12d-npd-1',
            'sourceFilePath': 'gs://hnb-poc-demo/ach.csv',
            'secretId':'file-decrypt-password',
            'outputLocation': 'gs://hnb-poc-demo/decrypted/ach.csv',
            'auditTableId': 'olap_dataset.decrypt_audit'

        },
    dag=dag
    )

# Set the audit record to failed with failed decryption comments
decrypt_failed_audit_entry = BigQueryInsertJobOperator(
                task_id="decrypt_failed_audit_entry",
                configuration={
                    "query": {
                        "query": "UPDATE `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` "
                                 "SET status= 'failed', comments = 'File decryption failed' WHERE md5_hash = '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('md5hash')}}'",
                        "useLegacySql": False,
                        "priority": "BATCH",
                    }
                },  # Trigger this task only if the previous task is successful
    dag=dag,
    trigger_rule='one_failed'
)

# Update the comments on the audit record for successful decryption
decrypt_success_audit_entry = BigQueryInsertJobOperator(
                task_id="decrypt_success_audit_entry",
                configuration={
                    "query": {
                        "query": "UPDATE `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` "
                                 "SET  comments = 'File decrypted successfully.' WHERE md5_hash = '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('md5hash')}}'",
                        "useLegacySql": False,
                        "priority": "BATCH",
                    }
                },  # Trigger this task only if the previous task is successful
    dag=dag,
    trigger_rule='one_success'
)

# Update the comments on the audit record to start the data load process
create_data_load_audit_entry = BigQueryInsertJobOperator(
                task_id="create_data_load_audit_entry",
                configuration={
                    "query": {
                        "query": "UPDATE `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` "
                                 "SET  comments = 'Starting Data Load job' WHERE md5_hash = '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('md5hash')}}'",
                        "useLegacySql": False,
                        "priority": "BATCH",
                    }
                },  # Trigger this task only if the previous task is successful
    dag=dag,
    trigger_rule='one_success'
)

# Trigger the dataflow job to load the CSV data to BigTable
data_load_dataflow = DataflowTemplatedJobStartOperator(
        task_id='data_load_dataflow',
        job_name='batch-test-container',
        project_id='us-gcp-ame-con-ff12d-npd-1',
        template='gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/batch_poc/templates/csv_batch_load_ed_testing',
        location='us-east4',  
        gcp_conn_id='google_cloud_default',
        parameters={
            'projectId': 'us-gcp-ame-con-ff12d-npd-1',
            'sourceFilePath': 'gs://hnb-poc-demo/decrypted/ach.csv',
            'instanceId': 'payment-test-instance',
            'batchDataTableId': 'csv_load',
            'auditTableId': 'olap_dataset.test_audit'

        },
    dag=dag
    )

# Update the audit record with Failed data load status
data_load_failed_audit_entry = BigQueryInsertJobOperator(
                task_id="data_load_failed_audit_entry",
                configuration={
                    "query": {
                        "query": "UPDATE `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` "
                                 "SET status = 'failed', comments = 'ACH data load failed' WHERE md5_hash = '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('md5hash')}}'",
                        "useLegacySql": False,
                        "priority": "BATCH",
                    }
                },  # Trigger this task only if the previous task is successful
    dag=dag,
    trigger_rule='one_failed'
)

# Update the audit record with successful data load status and comments
data_load_success_audit_entry = BigQueryInsertJobOperator(
                task_id="data_load_success_audit_entry",
                configuration={
                    "query": {
                        "query": "UPDATE `us-gcp-ame-con-ff12d-npd-1.olap_dataset.file_ingestion_audit` "
                                 "SET status = 'success', comments = 'ACH data load successful' WHERE md5_hash = '{{task_instance.xcom_pull(task_ids='validate_file_info', key='file_info').get('md5hash')}}'",
                        "useLegacySql": False,
                        "priority": "BATCH",
                    }
                },  # Trigger this task only if the previous task is successful
    dag=dag,
    trigger_rule='one_success'
)

# Set task dependencies
gcs_file_check >> validate_file_info >> branch_task >> [audit_zero_byte_file, audit_processed_file, create_file_audit_decrypt]
create_file_audit_decrypt >> decrypt_dataflow >> [decrypt_failed_audit_entry, decrypt_success_audit_entry]
decrypt_success_audit_entry >> create_data_load_audit_entry  >> data_load_dataflow >> [data_load_success_audit_entry, data_load_failed_audit_entry]
