# Cloud Composer POC
# ACH Batch DAG

This DAG (ach_batch_load.py) orchestrates a batch data ingestion pipeline using Google Cloud Composer (Apache Airflow). It’s designed to automate the loading of ACH batch transaction data from source systems (e.g. GCS) into downstream data stores such as Bigtable, BigQuery, or other GCP services.

# Key Features

- GCS Integration
Monitors Google Cloud Storage buckets for new ACH data files.

- Dataflow Orchestration
Triggers a Dataflow job (streaming or batch) to process and transform the ACH files.

- Error Handling & Notifications
Includes retry logic and can integrate with Slack or email for error alerts.

- Parameterization
Supports dynamic parameter passing via Airflow Variables or Environment Variables.

# File Overview

ach_batch_load.py	: Airflow DAG definition for ACH batch ingestion.

# Pre-requsite 

Before deploying the DAG, ensure the following Airflow Variables (or Environment Variables) are configured in Cloud Composer:

Variable	Description
gcs_input_bucket	GCS bucket containing ACH files
dataflow_template_path	GCS path to your Dataflow template
temp_location	GCS bucket for Dataflow temporary files
project_id	GCP project ID
region	GCP region (e.g. us-central1)
service_account_email	Service Account email for Dataflow execution

# Deployment

- Place the ach_batch_load.py file into the Cloud Composer dags/ folder:
   gsutil cp ach_batch_load.py gs://YOUR-COMPOSER-BUCKET/dags/

-  Verify the DAG is listed in the Airflow UI under DAGs.

- Trigger the DAG manually or wait for its scheduled interval.

# Permissions

Ensure the Composer service account has the necessary roles:

roles/dataflow.developer — To launch Dataflow jobs.
roles/storage.objectViewer — To read input files from GCS.
roles/bigquery.dataEditor — If writing to BigQuery.
roles/bigtable.user — If writing to Bigtable.

# Monitoring

Use the Airflow UI to monitor DAG runs, task status, logs, and troubleshoot any issues. Logs can also be exported to Stackdriver for advanced analysis.