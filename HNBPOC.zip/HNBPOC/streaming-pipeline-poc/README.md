# HNB Event Aggregation POC

```
This project is a Dataflow pipeline designed to process Pub/Sub events and apply respective business logic.
The pipeline validates incoming messages, tags them as valid or invalid, 
and writes the valid messages to Pub/Sub and the invalid messages to BigQuery audit table.
```
## Requirements

To run this pipeline, you need the following dependencies:
 
- `apache-beam==2.64.0`
- `google-api-core==2.24.0`
- `google-api-python-client==2.158.0`
- `google-apitools==0.5.31`
- `google-auth==2.37.0`
- `google-auth-httplib2==0.2.0`
- `google-cloud-audit-log==0.3.0`
- `google-cloud-bigquery==3.27.0`
- `google-cloud-bigquery-storage==2.27.0`
- `google-cloud-bigtable==2.28.0`
- `google-cloud-core==2.4.1`
- `google-cloud-language==2.16.0`
- `google-cloud-logging==3.11.3`
- `google-cloud-pubsub==2.27.3`
- `google-cloud-storage==2.19.0`
- `google-crc32c==1.6.0`
- `google-resumable-media==2.7.2`
- `googleapis-common-protos==1.66.0`
- `grpc-google-iam-v1==0.14.0`
- `grpc-interceptor==0.15.4`
- `grpcio==1.65.5`
- `grpcio-status==1.62.3`
- `numpy==2.1.3`
- `oauth2client==4.1.3`
- `oauthlib==3.2.2`
- `pandas==2.2.3`
- `pytz==2024.2`
- `PyYAML==6.0.2`
- `regex==2024.11.6`

## Installation

To install the required dependencies, run:

```sh
pip install -r requirements.txt
```


## Pipeline Overview
The pipeline performs the following steps:  
- Reads messages from a Pub/Sub subscription.
- Applies windowing to the messages.
- Write raw messages to BigTable.
- Validates the messages using the ValidatePubSubMessages class.
- Tags messages as valid or invalid.
- Writes valid messages to a target Pub/Sub topic.
- Writes invalid messages to a BigQuery table.

## Custom Pipeline Options
The pipeline uses custom options defined in the MyOptions class. These options include:  
- **achSubscriptionName**: The name of the Pub/Sub subscription to read for ACH transactions.
- **memopostSubscriptionName**: The name of the Pub/Sub subscription to read for MEMOPOST transactions.
- **hoganSubscriptionName**: The name of the Pub/Sub subscription to read for HOGAN transactions.
- **projectId**: The GCP project ID where BigTable is present.
- **instanceId**: The BigTable instance ID.
- **tableId**: The BigTable table ID.
- **auditTableId**: The BigQuery audit table ID.
- **targetPubSubTopic**: The target Pub/Sub topic where the processed messages will be sent.

## Current Pipeline Graph for Aggregating all the messages
![pipeline1.png](pipeline1.png)

## Command to Build
ACH:
```python3 -m eventAggregationPipeline --runner DataflowRunner --project us-gcp-ame-con-ff12d-npd-1    --staging_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/staging/ach    --template_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/ach_to_tds --region us-east4 --requirements_file requirements.txt --instanceId hnb-demo-orals --rawDataTableId staging_raw_messages --aggregatedDataTableId aggregated_transaction_table --projectId us-gcp-ame-con-ff12d-npd-1 --auditTableId olap_dataset.test_audit --targetPubSubTopic projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing --subscriptionName projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/ACH-TRANSACTIONS-sub --paymentType ACH```

MEMOPOST:
```python3 -m eventAggregationPipeline --runner DataflowRunner --project us-gcp-ame-con-ff12d-npd-1    --staging_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/staging/memopost    --template_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/memopost_to_tds --region us-east4 --requirements_file requirements.txt --instanceId hnb-demo-orals --rawDataTableId staging_raw_messages --aggregatedDataTableId aggregated_transaction_table --projectId us-gcp-ame-con-ff12d-npd-1 --auditTableId olap_dataset.test_audit --targetPubSubTopic projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing --subscriptionName projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/PENDING-TRANSACTIONS-sub --paymentType MEMOPOST```

HOGAN:
```python3 -m eventAggregationPipeline --runner DataflowRunner --project us-gcp-ame-con-ff12d-npd-1    --staging_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/staging/hogan    --template_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/hogan_to_tds --region us-east4 --requirements_file requirements.txt --instanceId hnb-demo-orals --rawDataTableId staging_raw_messages --aggregatedDataTableId aggregated_transaction_table --projectId us-gcp-ame-con-ff12d-npd-1 --auditTableId olap_dataset.test_audit --targetPubSubTopic projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing --subscriptionName projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/POSTED-TRANSACTIONS-sub --paymentType HOGAN```

EEH TO EQH:
```python3 -m eventToBigTable --runner DataflowRunner --project us-gcp-ame-con-ff12d-npd-1 --staging_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/staging/eeh_to_eqh --template_location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/eeh_to_eqh --region us-east4  --requirements_file requirements.txt --aggregatedSubscriptionName projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/default-test --instanceId hnb-demo-orals --tableId aggregated_transaction_table --projectId us-gcp-ame-con-ff12d-npd-1```

## Command to Run
ACH:
```gcloud dataflow jobs run ach-to-tds-demo-run-1    --gcs-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/ach_to_tds --region us-east4 --max-workers=5 --staging-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/temp/ach --worker-machine-type=n1-standard-4 --parameters projectId=us-gcp-ame-con-ff12d-npd-1,instanceId=hnb-demo-orals,rawDataTableId=staging_raw_messages,aggregatedDataTableId=aggregated_transaction_table,auditTableId=olap_dataset.test_audit,targetPubSubTopic=projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing,subscriptionName=projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/ACH-TRANSACTIONS-sub,paymentType=ACH```

MEMOPOST:
```gcloud dataflow jobs run memopost-to-tds-demo-run-1    --gcs-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/memopost_to_tds --region us-east4 --max-workers=5 --staging-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/temp/memopost --worker-machine-type=n1-standard-4 --parameters projectId=us-gcp-ame-con-ff12d-npd-1,instanceId=hnb-demo-orals,rawDataTableId=staging_raw_messages,aggregatedDataTableId=aggregated_transaction_table,auditTableId=olap_dataset.test_audit,targetPubSubTopic=projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing,subscriptionName=projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/PENDING-TRANSACTIONS-sub,paymentType=MEMOPOST```

HOGAN:
```gcloud dataflow jobs run hogan-to-tds-demo-run-1    --gcs-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/hogan_to_tds --region us-east4 --max-workers=5 --staging-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/temp/hogan --worker-machine-type=n1-standard-4 --parameters projectId=us-gcp-ame-con-ff12d-npd-1,instanceId=hnb-demo-orals,rawDataTableId=staging_raw_messages,aggregatedDataTableId=aggregated_transaction_table,auditTableId=olap_dataset.test_audit,targetPubSubTopic=projects/us-gcp-ame-con-ff12d-npd-1/topics/payment-hnb-testing,subscriptionName=projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/POSTED-TRANSACTIONS-sub,paymentType=HOGAN```

EEH TO EQH:
```gcloud dataflow jobs run eeh-to-eqh-demo-run-1 --gcs-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/templates/eeh_to_eqh --region us-east4 --staging-location gs://us-gcp-ame-con-ff12d-npd-1-dataflow-stage/demo_run/temp/eeh_to_eqh --max-workers=5 --num-workers=1 --worker-machine-type=n1-standard-4 --parameters projectId=us-gcp-ame-con-ff12d-npd-1,aggregatedSubscriptionName=projects/us-gcp-ame-con-ff12d-npd-1/subscriptions/default-test,instanceId=hnb-demo-orals,tableId=aggregated_transaction_table```
