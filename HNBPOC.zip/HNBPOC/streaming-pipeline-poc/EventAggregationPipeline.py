# Dataflow Pipeline code to Process PubSub Events and apply respective Business Logic
# Standard libraries for data handling and logging
import datetime
import json
import logging

# Standard library imports
# Apache Beam components for data processing pipeline
import apache_beam as beam
from apache_beam.io.gcp.bigquery import WriteToBigQuery
from apache_beam.io.gcp.bigtableio import WriteToBigTable
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions, SetupOptions
from apache_beam.options.value_provider import ValueProvider
# Google Cloud BigTable components
from google.cloud import bigtable
from google.cloud.bigtable import row
from google.cloud.bigtable.row import DirectRow


class TransactionValidationError(Exception):
    """Exception raised when transaction validation fails."""

    def __init__(self, errors):
        self.errors = errors
        # Combine all errors into a single message
        error_message = "\n".join([f"- {error}" for error in errors])
        message = f"Transaction validation failed with {len(errors)} errors:\n{error_message}"
        super().__init__(message)


# Creates an audit record with message details, timestamp, and metadata
def get_audit_record(message, metadata, row_key):
    """
    Creates a structured audit record for tracking and error handling
    Args:
        message: The original message content
        metadata: Additional information about the message processing
        row_key: Unique identifier for the record
    Returns:
        Dictionary with audit information
    """
    return {
        'message_body': str(message),
        'insert_timestamp': datetime.datetime.now().isoformat(),
        'metadata': metadata,
        'row_key': row_key
    }


# Retrieves a row from BigTable using the row key
def read_row_from_bigtable(project_id, instance_id, table_id, row_key):
    """
    Reads a specific row from BigTable using the provided row key
    Args:
        project_id: GCP project ID
        instance_id: BigTable instance ID
        table_id: BigTable table ID
        row_key: Unique identifier for the row
    Returns:
        DirectRow object if found, None otherwise
    """
    client = bigtable.Client(project=project_id, admin=True)
    instance = client.instance(instance_id)
    table = instance.table(table_id)

    total_versions = None
    latest_cell = None
    direct_row = None
    row = table.read_row(row_key.encode('utf-8'))

    if row:
        # Convert row to DirectRow for mutation operations
        direct_row = DirectRow(row_key.encode('utf-8'))

        for column_family_id, columns in row.cells.items():
            for column, cells in columns.items():
                latest_cell = cells[0]  # Only using the latest value for reconciliation
                direct_row.set_cell(
                    column_family_id,
                    column.decode('utf-8'),
                    latest_cell.value.decode('utf-8'),
                    timestamp=latest_cell.timestamp
                )
    else:
        # If row doesn't exist, log that it's a new record
        logging.info(f"Not found: {row_key}")

    return direct_row


# Extracts column families and their values from BigTable mutations
def extract_families(mutations):
    """
    Extracts column families and their values from BigTable mutation objects
    Args:
        mutations: List of mutation objects from BigTable
    Returns:
        Dictionary of families and their column values
    """
    families = {}

    for mutation in mutations:
        set_cell = mutation.set_cell
        family_name = set_cell.family_name
        column_qualifier = set_cell.column_qualifier
        value = set_cell.value

        if family_name not in families:
            families[family_name] = {}

        families[family_name][column_qualifier] = value

    return families


def get_nested_value(dictionary, path, default=None):
    """
    Retrieves a value from a nested dictionary using dot notation.
    Handles array indexing with [n] notation.
    """
    # Handle empty path
    if not path:
        return default

    # Split the path into parts
    parts = path.split('.')
    current = dictionary

    # Navigate through the dictionary
    for part in parts:
        # Handle array indexing (e.g., "accounts[0]")
        if '[' in part and part.endswith(']'):
            key, index_str = part.split('[', 1)
            index = int(index_str[:-1])  # Remove ']' and convert to int

            if key not in current:
                return default

            if not isinstance(current[key], list) or index >= len(current[key]):
                return default

            current = current[key][index]

        # Regular dictionary access
        elif part in current:
            current = current[part]
        else:
            return default

    return current


def validate_transaction(transaction, schema_json):
    """
    Validates a transaction against a schema defined in a JSON file.

    Args:
        transaction (dict): The transaction to validate
        schema_json (str): JSON schema

    Returns:
        tuple: (is_valid: bool, errors: list) - Validation result and error messages
    """
    # Initialize result
    errors = []

    # Validate all fields in the schema
    for field_name, field_config in schema_json.items():
        # Skip if this field is just a mapping path without validation rules
        if isinstance(field_config, str):
            continue

        # Get the source path for this field
        source_path = field_config.get("path")
        if not source_path:
            continue

        # Get the value from transaction
        value = get_nested_value(transaction, source_path)

        # Check if field is required
        if field_config.get("required", False) and value is None:
            errors.append(f"Required field '{field_name}' is missing (path: {source_path})")
            continue

        # Skip further validation if value is None and field is not required
        if value is None:
            continue

        # Validate data type
        expected_type = field_config.get("type")
        if expected_type:
            if expected_type == "string" and not isinstance(value, str):
                errors.append(f"Field '{field_name}' should be a string")
            elif expected_type == "number" and not isinstance(value, (int, float)):
                errors.append(f"Field '{field_name}' should be a number")
            elif expected_type == "integer" and not isinstance(value, int):
                errors.append(f"Field '{field_name}' should be an integer")
            elif expected_type == "boolean" and not isinstance(value, bool):
                errors.append(f"Field '{field_name}' should be a boolean")
            elif expected_type == "array" and not isinstance(value, list):
                errors.append(f"Field '{field_name}' should be an array")
            elif expected_type == "object" and not isinstance(value, dict):
                errors.append(f"Field '{field_name}' should be an object")

        # Check enum values if specified
        if "enum" in field_config and value not in field_config["enum"]:
            errors.append(f"Field '{field_name}' value '{value}' is not in allowed values: {field_config['enum']}")

        # Check min/max constraints for numeric values
        if isinstance(value, (int, float)):
            if "minimum" in field_config and value < field_config["minimum"]:
                errors.append(f"Field '{field_name}' value {value} is less than minimum {field_config['minimum']}")
            if "maximum" in field_config and value > field_config["maximum"]:
                errors.append(f"Field '{field_name}' value {value} exceeds maximum {field_config['maximum']}")

        # Check string length constraints
        if isinstance(value, str):
            if "minLength" in field_config and len(value) < field_config["minLength"]:
                errors.append(f"Field '{field_name}' length is less than minimum length {field_config['minLength']}")
            if "maxLength" in field_config and len(value) > field_config["maxLength"]:
                errors.append(f"Field '{field_name}' length exceeds maximum length {field_config['maxLength']}")
            if "pattern" in field_config:
                import re
                if not re.match(field_config["pattern"], value):
                    errors.append(f"Field '{field_name}' does not match required pattern: {field_config['pattern']}")

    return len(errors) == 0, errors

@staticmethod
def map_ach_to_tds(ach_transaction):
    """Map ACH transaction to TDS format."""
    source = ach_transaction["payload"]["account-deposits-achtransactions"]
    metadata = source.get("_metadata", {})

    tds = {
        "transactionId": source.get("sourceTransactionReference"),
        "accountDepositsAchFileId": source.get("accountDepositsAchFileId"),
        "accountDepositsAchBatchId": source.get("accountDepositsAchBatchId"),
        "accountId": source.get("accountId"),
        "transactionStatusType": source.get("transactionStatusType"),
        "bankNumber": source.get("bankNumber"),
        "sourceTransactionCode": source.get("sourceTransactionCode"),
        "sourceTransactionDescription": source.get("sourceTransactionDescription"),
        "transactionAmount": source.get("transactionAmount"),
        "currencyCode": source.get("currencyCode"),
        "transactionAmountType": source.get("transactionAmountType"),
        "transactionTimeStamp": source.get("transactionTimeStamp"),
        "postingDate": source.get("postingDate"),
        "shortDescription": source.get("shortDescription"),
        "traceNumber": source.get("traceNumber"),
        "effectiveDate": source.get("effectiveDate"),
        "transactionNote": source.get("transactionNote"),
        "standardEntryClassReference": source.get("standardEntryClassReference"),
        "originatorReference": source.get("originator", {}).get("originatorReference"),
        "originatorName": source.get("originator", {}).get("originatorName"),
        "receiverReference": source.get("receiver", {}).get("receiverReference"),
        "receiverName": source.get("receiver", {}).get("receiverName"),
        "addendaText": source.get("addendaText"),
        "baiCode": source.get("baiCode"),
        "_metadata": metadata
    }

    return str(tds)

@staticmethod
def map_memopost_to_tds(memopost_transaction):
    """Map Memopost transaction to TDS format."""
    source = memopost_transaction["pendingtransactions"]
    metadata = source.get("_metadata", {})

    tds = {
        "transactionId": source.get("sourceTransactionReference"),
        "accountId": source.get("accountId"),
        "transactionStatusType": "PENDING",  # Based on transaction type
        "transactionAmount": source.get("transactionAmount"),
        "transactionAmountType": source.get("transactionAmountType"),
        "transactionCurrency": source.get("transactionCurrency"),
        "currencyCode": source.get("transactionCurrency"),
        "postingDate": source.get("postingDate"),
        "description": source.get("description"),
        "sourceTransactionCode": source.get("sourceTransactionCode"),
        "sourceTransactionDate": source.get("sourceTransactionDate"),
        "sourceTransactionTime": source.get("sourceTransactionTime"),
        "sourceSystemReference": source.get("sourceSystemReference"),
        "sourceSequenceNumber": source.get("sourceSequenceNumber"),
        "sourceTransactionType": source.get("sourceTransactionType"),
        "transactionRecordedTimestamp": source.get("transactionRecordedTimestamp"),
        "cashAmount": source.get("cashAmount"),
        "checkAmount": source.get("checkAmount"),
        "feeAmount": source.get("feeAmount"),
        "sicCode": source.get("sicCode"),
        "forcedIndicator": source.get("forcedIndicator"),
        "availableBalanceCurrency": source.get("availableBalanceCurrency"),
        "availableBalanceAmount": source.get("availableBalanceAmount"),
        "transactionCity": source.get("transactionCity"),
        "transactionState": source.get("transactionState"),
        "transactionAuthorizationCode": source.get("transactionAuthorizationCode"),
        "pendingPenaltyFeeAmount": source.get("pendingPenaltyFeeAmount"),
        "isoTransactionCode": source.get("isoTransactionCode"),
        "carryoverIndicator": source.get("carryoverIndicator"),
        "additionalFundingUsedIndicator": source.get("additionalFundingUsedIndicator"),
        "additionalFundingUsedAmount": source.get("additionalFundingUsedAmount"),
        "customerId": source.get("customerId"),
        "loginType": source.get("loginType"),
        "loginId": source.get("loginId"),
        "_metadata": metadata
    }

    return str(tds)

@staticmethod
def map_hogan_to_tds(hogan_transaction):
    """Map Hogan transaction to TDS format."""
    source = hogan_transaction["account-deposits-demandpostedtransactions"]
    metadata = source.get("_metadata", {})

    tds = {
        "transactionId": source.get("accountDepositsDemandpostedtransactionId"),
        "accountId": source.get("accountId"),
        "accountNumberMasked": source.get("accountNumberMasked"),
        "productType": source.get("productType"),
        "currencyCode": source.get("currencyCode"),
        "transactionCode": source.get("transactionCode"),
        "postingDate": source.get("postedDate"),
        "transactionAmount": source.get("transactionAmount"),
        "detailedTransactionDescription": source.get("detailedTransactionDescription"),
        "runningBalanceAtPostingAmount": source.get("runningBalanceAtPostingAmount"),
        "postedSequence": source.get("postedSequence"),
        "extendedDescription": source.get("extendedDescription"),
        "effectiveDate": source.get("effectiveDate"),
        "transactionAmountType": source.get("transactionAmountType"),
        "suppressViewIndicator": source.get("suppressViewIndicator"),
        "transactionDescriptionType": source.get("transactionDescriptionType"),
        "sourceTransactionReference": source.get("sourceTransactionReference"),
        "documentReference": source.get("documentReference"),
        "serialNumber": source.get("serialNumber"),
        "sourceInformation": source.get("sourceInformation"),
        "transactionRecordedTimestamp": source.get("transactionRecordedTimestamp"),
        "statementDate": source.get("statementDate"),
        "summaryIndicator": source.get("summaryIndicator"),
        "totalFloatAmount": source.get("totalFloatAmount"),
        "floatDayAmount": source.get("floatDayAmount"),
        "uncollectedDayAmount": source.get("uncollectedDayAmount"),
        "cashAmount": source.get("cashAmount"),
        "paperIndicator": source.get("paperIndicator"),
        "_metadata": metadata
    }

    return str(tds)


def map_to_tds(transaction, transaction_type):
    """
    Maps various transaction types to the TDS format.

    Args:
        transaction (dict): The source transaction
        transaction_type (str): One of 'ach', 'memopost', or 'hogan'

    Returns:
        str: Transaction mapped to TDS format
    """
    # Call the appropriate mapping function based on transaction type
    if transaction_type.lower() == 'ach':
        return map_ach_to_tds(transaction)
    elif transaction_type.lower() == 'memopost':
        return map_memopost_to_tds(transaction)
    elif transaction_type.lower() == 'hogan':
        return map_hogan_to_tds(transaction)
    else:
        raise ValueError(f"Unsupported transaction type: {transaction_type}")


# Validates incoming PubSub messages
class ValidateMessages(beam.DoFn):
    """
    DoFn for validating PubSub messages and tagging them as valid or invalid
    Uses multi-output to separate valid and invalid messages
    """
    # Output tags for valid and invalid messages
    OUTPUT_TAG_VALID_MESSAGES = 'tag_valid_messages'
    OUTPUT_TAG_INVALID_MESSAGES = 'tag_invalid_messages'

    def __init__(self, source, *unused_args, **unused_kwargs):
        """
        Initialize with source identifier (ACH, MEMOPOST, HOGAN)
        """
        self.source = source

    def process(self, element, raw_message_schema_config_si):
        """
        Processes and validates each incoming message
        Args:
            element: PubSub message
        Yields:
            Tagged outputs for valid or invalid messages
        """
        try:
            # Decode the message if it is in bytes
            message = element.decode("utf-8")
            if message is None or (message.startswith("{", 0) == False):
                raise ValueError("Message is None or not a valid JSON string")
            else:
                # Validate the message against the schema
                message_json = json.loads(message.replace("'", '"'))
                # Tag message with its source (ACH, MEMOPOST, HOGAN)
                raw_message_validation_rules = json.loads(raw_message_schema_config_si[0])

                is_valid, validation_errors = validate_transaction(message_json, raw_message_validation_rules)

                if is_valid:
                    # Tag message with its source (ACH, MEMOPOST, HOGAN)
                    message_json["topic_source"] = self.source
                    # Output valid message (encoded as bytes for Pub/Sub)
                    yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_VALID_MESSAGES, (str(message_json)).encode("utf-8"))
                else:
                    raise TransactionValidationError(validation_errors)

        except TransactionValidationError as tve:
            # Log error and create audit record for invalid message
            audit_record = {
                'message_body': str(element),
                'insert_timestamp': datetime.datetime.now().isoformat(),
                'metadata': f"Validation errors: {tve.errors}",
                'row_key': "Row key not generated for the record"
            }
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_INVALID_MESSAGES, audit_record)

        except Exception as e:
            # Log error and create audit record for invalid message
            audit_record = {
                'message_body': str(element),
                'insert_timestamp': datetime.datetime.now().isoformat(),
                'metadata': f"Exception raised while processing pubsub message {e}",
                'row_key': "Row key not generated for the record"
            }
            yield beam.pvalue.TaggedOutput(self.OUTPUT_TAG_INVALID_MESSAGES, audit_record)


# Transforms messages to BigTable format
class TransformDataToBigTable(beam.DoFn):
    """
    Transforms PubSub messages into BigTable row format
    """

    def process(self, element):
        """
        Processes each element into a BigTable row
        Args:
            element: Valid PubSub message
        Yields:
            BigTable DirectRow object with cells for each message field
        """
        try:
            # Decode the message if it is in bytes
            message_raw = (element.decode("utf-8")).replace("'", '"')
            message = json.loads(message_raw)

            # Generate unique row key using transaction and account IDs
            account_deposits_ach_transaction_id = message.get('accountDepositsAchTransactionId', 'UNKNOWN')
            account_id = message.get('accountId', 'UNKNOWN')
            row_key_identifier = f"{account_deposits_ach_transaction_id}#{account_id}".encode('utf-8')

            # Set the current timestamp for BigTable
            bigtable_timestamp = datetime.datetime.now()

            # Create DirectRow object and add cells for each message field
            bt_row_obj = row.DirectRow(row_key_identifier)
            for key, value in message.items():
                if value is not None:
                    column_family_id = "raw_message"
                    # Handle different data types appropriately
                    if isinstance(value, str):
                        bt_row_obj.set_cell(column_family_id, key, value, timestamp=bigtable_timestamp)
                    elif isinstance(value, (int, float)):
                        bt_row_obj.set_cell(column_family_id, key, str(value), timestamp=bigtable_timestamp)
                    elif isinstance(value, dict):
                        bt_row_obj.set_cell(column_family_id, key, json.dumps(value), timestamp=bigtable_timestamp)
                    elif isinstance(value, list):
                        bt_row_obj.set_cell(column_family_id, key, json.dumps(value), timestamp=bigtable_timestamp)
                    elif isinstance(value, bool):
                        bt_row_obj.set_cell(column_family_id, key, str(value), timestamp=bigtable_timestamp)
                    elif isinstance(value, datetime):
                        bt_row_obj.set_cell(column_family_id, key, value.isoformat(), timestamp=bigtable_timestamp)
                    else:
                        bt_row_obj.set_cell(column_family_id, key, str(value), timestamp=bigtable_timestamp)
            yield bt_row_obj

        except Exception as e:
            logging.error(f"Error processing element: {e}")


# Implements business logic for event sequencing
class SequenceOfEvents(beam.DoFn):
    """
    Implements business logic for tracking event sequence across different sources
    Validates and tracks the order in which events are received from different systems
    """

    def __init__(self, project, instance_id, table_id, *unused_args, **unused_kwargs):
        """
        Initialize with BigTable connection parameters
        """
        self.table = None
        self.instance = None
        self.bigtable_client = None
        self.project = project
        self.instance_id = instance_id
        self.table_id = table_id

    def setup(self):
        """
        Establish BigTable connections during worker setup
        """
        self.bigtable_client = bigtable.Client(project=self.project, admin=True)
        self.instance = self.bigtable_client.instance(self.instance_id)
        self.table = self.instance.table(self.table_id)

    def teardown(self):
        """
        Close BigTable connections during worker teardown
        """
        self.bigtable_client.close()

    def process(self, element):
        """
        Process each element according to event sequencing rules
        Tracks and validates the order of events from different sources
        Args:
            element: Valid message from one of the sources
        Yields:
            Processed message with source_order tracking
        """
        different_events = ['created', 'pending', 'posted']
        try:
            # Decode the message
            message_raw = element.decode("utf-8")
            message_json = json.loads(message_raw.replace("'", '"'))

            # Generate row key for BigTable lookup
            account_deposits_ach_transaction_id = message_json.get('accountDepositsAchTransactionId', 'UNKNOWN')
            account_id = message_json.get('accountId', 'UNKNOWN')
            row_key_identifier = f"{account_deposits_ach_transaction_id}#{account_id}"

            # Fetch existing record from BigTable
            bigtable_record = read_row_from_bigtable(self.project, self.instance_id, self.table_id,
                                                     row_key_identifier)

            if bigtable_record is not None:
                # Extract existing data from BigTable record
                bigtable_record_list = bigtable_record.__dict__["_pb_mutations"]
                bigtable_record_mutation_dict = extract_families(bigtable_record_list)
                source_order = None

                # Apply business rules based on event source and existing order

                # Process ACH event
                if message_json.get("topic_source") == "ACH":
                    if (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "MEMOPOST":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+ACH"
                        logging.error(f"Transaction recevied in order of {source_order}")

                    elif (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "HOGAN":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+ACH"
                        logging.error(f"Transaction recevied in order of {source_order}")

                # Process MEMOPOST event
                if message_json.get("topic_source") == "MEMOPOST":
                    if bigtable_record_mutation_dict.get("source_order") == "ACH":
                        # Valid case - No Logging
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+MEMOPOST"

                    elif (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "ACH":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+MEMOPOST"
                        logging.error(f"Transaction recevied in order of {source_order}")

                    elif (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "HOGAN":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+MEMOPOST"
                        logging.error(f"Transaction recevied in order of {source_order}")

                # Process HOGAN event
                if message_json.get("topic_source") == "HOGAN":
                    if (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "ACH":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+HOGAN"
                        logging.error(f"Transaction recevied in order of {source_order}")

                    elif bigtable_record_mutation_dict.get("source_order") == "MEMOPOST":
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+HOGAN"
                        logging.error(f"Transaction recevied in order of {source_order}")

                    elif (bigtable_record_mutation_dict.get("source_order")).split("+")[-1] == "MEMOPOST":
                        # Valid case - No Logging
                        source_order = bigtable_record_mutation_dict.get("source_order") + "+HOGAN"

                # Add source_order to message and yield
                message_json["source_order"] = source_order

                # Convert transaction to TDS format
                converting_to_tds = map_to_tds(transaction=message_json,
                                               transaction_type=message_json.get("topic_source"))
                yield converting_to_tds.encode("utf-8")

            else:
                # Handle new record (no previous entry in BigTable)
                # Track initial source and log if sequence is not as expected
                order_of_entry = message_json.get('topic_source')
                if order_of_entry == "ACH":
                    message_json["source_order"] = order_of_entry
                elif order_of_entry == "MEMOPOST":
                    message_json["source_order"] = order_of_entry
                    logging.error("ACH entry not available for the given transaction in BigTable")
                elif order_of_entry == "HOGAN":
                    message_json["source_order"] = order_of_entry
                    logging.error("ACH & MEMOPOST entry not available for the given transaction in BigTable")

                # Convert transaction to TDS format
                converting_to_tds = map_to_tds(transaction=message_json,
                                               transaction_type=message_json.get("topic_source"))

                yield converting_to_tds.encode("utf-8")
        except Exception as e:
            logging.error(f"Error processing element: {e}")


# Custom pipeline options for configuration
class MyOptions(PipelineOptions):
    """
    Custom pipeline options for configuring data sources and destinations
    """
    @classmethod
    def _add_argparse_args(cls, parser):
        # Add custom pipeline arguments
        parser.add_argument(
            '--schemaFilePath',
            help='GCS file path to the respective Payment schema validation file')
        parser.add_argument(
            '--subscriptionName',
            help='Topic Subscription Name for Different Payment System')
        parser.add_argument(
            '--paymentTypeSystem',
            help='Source Payment Type')
        parser.add_argument(
            '--projectId',
            help='GCP Project ID where BigTable is present')
        parser.add_argument(
            '--instanceId',
            help='BigTable Instance ID')
        parser.add_argument(
            '--rawDataTableId',
            help='BigTable Table ID')
        parser.add_argument(
            '--aggregatedDataTableId',
            help='BigTable Table ID')
        parser.add_argument(
            '--auditTableId',
            help='BigQuery Audit Table Id')
        parser.add_argument(
            '--targetPubSubTopic',
            help='Target PubSub topic where the processed messages will be sent')


# Main pipeline execution function
def run(argv=None, save_main_session=True):
    """
    Main function that sets up and runs the pipeline
    Args:
        argv: Command line arguments
        save_main_session: Whether to save the main session
    """
    # Initialize pipeline options
    pipeline_options = PipelineOptions()
    dataflow_options = pipeline_options.view_as(MyOptions)

    # Configure pipeline to run on Dataflow as a streaming job
    pipeline_options.view_as(StandardOptions).runner = 'DataflowRunner'
    pipeline_options.view_as(StandardOptions).streaming = True
    pipeline_options.view_as(SetupOptions).save_main_session = save_main_session

    # Create the pipeline object
    pipeline_obj = beam.Pipeline(options=pipeline_options)

    # Read from PubSub topics and validate messages
    raw_message_schema_config = (pipeline_obj | "Read schema validation file from GCS"
                                 >> beam.io.ReadFromText(file_pattern=dataflow_options.schemaFilePath))
    raw_message_schema_config_si =  beam.pvalue.AsList(raw_message_schema_config)

    raw_messages = (
            pipeline_obj
            | "Read transactions from PubSub" >> beam.io.ReadFromPubSub(subscription=dataflow_options.subscriptionName)
            | "Window into Fixed Intervals" >> beam.WindowInto(beam.window.FixedWindows(5))
            | "Validate Messages" >> beam.ParDo(ValidateMessages(source=dataflow_options.paymentTypeSystem),
                                                raw_message_schema_config_si).with_outputs(
        ValidateMessages.OUTPUT_TAG_INVALID_MESSAGES, ValidateMessages.OUTPUT_TAG_VALID_MESSAGES)
    )

    # Apply business logic to valid messages from each source
    # Process valid ACH messages
    processed_messages = (raw_messages[ValidateMessages.OUTPUT_TAG_VALID_MESSAGES]
                          | "Implement Business Logic" >> beam.ParDo(SequenceOfEvents(dataflow_options.projectId,
                                                                                      dataflow_options.instanceId,
                                                                                      dataflow_options.aggregatedDataTableId))
                          )

    # Store raw messages in BigTable for reference
    (raw_messages[ValidateMessages.OUTPUT_TAG_VALID_MESSAGES]
     | "Convert to BigTable Row for RAW layer" >> beam.ParDo(TransformDataToBigTable())
     | "Writing raw events to BigTable" >> WriteToBigTable(
                project_id=dataflow_options.projectId,
                instance_id=dataflow_options.instanceId,
                table_id=dataflow_options.rawDataTableId))

    # Write processed messages to target PubSub topic
    (processed_messages | "Send the valid messages to PubSub"
     >> beam.io.WriteToPubSub(topic=dataflow_options.targetPubSubTopic))

    # Write invalid messages to BigQuery audit table
    (raw_messages[ValidateMessages.OUTPUT_TAG_INVALID_MESSAGES]
     | "Write error to BigQuery" >> WriteToBigQuery(project=dataflow_options.projectId,
                                                    table=dataflow_options.auditTableId,
                                                    write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                                                    create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER))

    # Run the pipeline
    pipeline_obj.run()


# Entry point of the Pipeline
if __name__ == "__main__":
    run()
